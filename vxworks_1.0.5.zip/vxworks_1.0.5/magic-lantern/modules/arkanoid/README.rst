Arkanoid game
=============

A stripped-down version of the old 1980s brick breaker-style game "Arkanoid". Use LEFT and RIGHT keys (or joystick) to play.

Arkanoid is an old arcade game developed in 1986 in the spirit of Atari's Breakout game from the 1970s. The game is pretty straight forward: you have a paddle (it's actually your ship) and you have to keep a ball from falling off the screen by bouncing it up and destroying the blocks in your way (from PetaPixel).

Tip: with an actor in the scene on hard difficulty (for example whilst playing during a paid shoot) the game becomes much more challenging but no less enjoyable (from EOSHD).

:Author: pravdomil.cz
:License: GPL
:Summary: Arkanoid game
:Forum: http://www.magiclantern.fm/forum/index.php?topic=7847.0
