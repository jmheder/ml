Self-testing routines
=====================

Testing routines for ML internals:

- stubs tests
- memory tests
- various burn-in tests

Please run these tests every now and then; when they fail, please report a bug.

:Author: a1ex
:License: GPL
:Summary: Stability tests
