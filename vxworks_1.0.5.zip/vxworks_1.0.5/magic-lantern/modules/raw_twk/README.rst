RAW decoding tweak
==================

An experimental module to speed up MLV/RAW playback by using hardware engines and optimized assembler.
EXPECT ANYTHING, UP TO AN EXPLODING CAMERA!!!

:License: GPL
:Summary: Speed up MLV/RAW decoding
:Authors: g3gg0
:Forum: http://www.magiclantern.fm/forum/index.php?topic=13163.0
