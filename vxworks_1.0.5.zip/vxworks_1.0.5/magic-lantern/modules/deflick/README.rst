Post Deflicker
==============

Generate sidecar (XMP/UFRaw) files for post deflicking.

:Author: a1ex
:License: GPL
:Credits: Audionut (Module)
:Summary: Post deflicker sidecar files
:Forum: http://www.magiclantern.fm/forum/index.php?topic=12585.0