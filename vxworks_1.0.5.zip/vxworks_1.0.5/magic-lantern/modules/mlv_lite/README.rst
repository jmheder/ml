Raw video v1.1 (MLV Lite)
=========================

Records 14-bit RAW video.

This is the original RAW recording module updated to MLV file format
(credits: dmilligan), but without the extra features from mlv_rec.
The performance should be identical to the old raw_rec v1.0.

You may want to load mlv_play for reviewing clips.

For details, please see the "Raw Video" section on the Magic Lantern forum.

:Authors: g3gg0, a1ex, dmilligan
:License: GPL
:Summary: Records 14-bit RAW video
:Forum: http://www.magiclantern.fm/forum/index.php?topic=16650.0

