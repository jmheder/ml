Input Method for Wheel
======================

This module is for entering text via scrollwheel


:Authors: g3gg0
:License: GPL
:Summary: IME Wheel module
