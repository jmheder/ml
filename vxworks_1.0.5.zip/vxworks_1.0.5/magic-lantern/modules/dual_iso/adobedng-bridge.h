#ifndef _ADOBEDNG_BRIDGE_H
#define _ADOBEDNG_BRIDGE_H

void dng_compress(const char* source, int lossy);

#endif
