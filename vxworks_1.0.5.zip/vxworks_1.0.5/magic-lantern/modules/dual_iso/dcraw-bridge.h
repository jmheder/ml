#ifndef __DCRAW_BRIDGE_H
#define __DCRAW_BRIDGE_H

int get_raw_info(const char * model, struct raw_info* orig);

#endif
