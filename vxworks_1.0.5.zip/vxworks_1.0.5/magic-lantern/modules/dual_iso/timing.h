/* for timing various routines */
void tic();
void toc();
