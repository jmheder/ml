Standard Input Method
=====================

This module is for entering text via cursor buttons.


:Authors: g3gg0
:License: GPL
:Summary: IME standard module
