io_crypt
========

This module hooks file I/O functions and adds an proprietary encryption mechanism.
Works on 5D3 and may work on 600D and 7D.

:Author: g3gg0
:License: GPL, BigDigits
:Summary: Encrypt files in real time
:Website: http://www.magiclantern.fm/forum/index.php?topic=9963.0


