Dummy IME
=========

This is a dummy Input Method Editor (IME) module useful as starting point for new implementations.

:Author: g3gg0
:License: GPL
:Summary: Dummy IME
:Forum: http://magiclantern.fm/forum/index.php?topic=6899.0