MPU Dumper
==========

This module dumps MPU memory.

The MPU is a microcontroller that handles buttons,
lens communication, shutter mechanism, viewfinder and maybe others.
It communicates with the main CPU (ICU) via SIO3/MREQ.

Details: http://magiclantern.wikia.com/wiki/Tx19a

:License: GPL
:Summary: Dump MPU memory
:Authors: a1ex, maqs


