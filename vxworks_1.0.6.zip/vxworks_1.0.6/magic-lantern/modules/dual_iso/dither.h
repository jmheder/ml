void fast_randn_init();
float fast_randn05();
