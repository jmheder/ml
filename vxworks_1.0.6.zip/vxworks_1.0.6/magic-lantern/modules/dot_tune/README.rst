Dot-Tune AFMA
=============

An automated version of the Dot-Tune focus tuning method.

http://youtu.be/7zE50jCUPhM

:Author: a1ex
:License: GPL
:Credits: Horshack (Dot-Tune method), YMP (algorithm tweaks)
:Summary: Autofocus fine-tuning.
:Forum: http://www.magiclantern.fm/forum/index.php?topic=4648.0
