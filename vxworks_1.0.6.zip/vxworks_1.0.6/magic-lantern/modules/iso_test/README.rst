iso_tests
========

Runs some tests to infer ISO response curve

:Summary: FOR DEVELOPERS ONLY - Runs some tests to infer ISO response curve
:Author: a1ex, nanomad (module)
:License: GPL
