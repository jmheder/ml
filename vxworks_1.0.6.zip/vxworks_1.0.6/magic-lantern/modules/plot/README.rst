Plotting
========

This module provides an API for other modules to plot graphs.
It is used for debugging mainly.

:Author: g3gg0
:License: GPL
:Summary: Plot graphs


