Benchmarks
==========

Benchmarks (speed tests):

- card benchmarks
- memory benchmarks
- various feature benchmarks

In particular, the quick card benchmark is useful
for diagnosing speed issues when recording RAW video.

:Author: a1ex
:License: GPL
:Summary: Benchmarks (speed tests)
:Forum: http://www.magiclantern.fm/forum/index.php?topic=12630.0
