Memory spy
==========

Spy your memory.

:License: GPL
:Summary: Spy your memory