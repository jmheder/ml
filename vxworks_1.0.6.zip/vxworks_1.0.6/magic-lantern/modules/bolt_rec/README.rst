bolt_rec
========

Start video on lightning.

:Author: g3gg0
:License: GPL
:Credits: a1ex (raw_rec)
:Summary: Start video on lightning
:Forum: http://www.magiclantern.fm/forum/index.php?topic=6303.0
