MRC Dumper
==========

This module shows some internal CP15 registers on screen.
For example the first register contains the CPU type (ARM946).

:License: GPL
:Summary: Display CP15 registers on screen
:Authors: g3gg0, a1ex


