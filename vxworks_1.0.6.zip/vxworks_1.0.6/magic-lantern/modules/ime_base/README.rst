Input Method Editor
===================

Base module for input modules.



:Authors: g3gg0
:License: GPL
:Summary: IME Base Module
