malloc checker
===============

This module is for reliability checks to the malloc subsystem.
One check allocates a block of predefined size and checks if the content is getting altered.
Some other check is flooding the memory subsystem with malloc/free calls.

This module appears in menu under Debug -> Burn-in tests.

:License: GPL
:Summary: malloc reliability checks
:Authors: g3gg0
