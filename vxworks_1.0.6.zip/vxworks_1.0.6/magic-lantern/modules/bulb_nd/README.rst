Bulb ND Utilities
=================

:Author: dmilligan
:License: GPL
:Summary: Long exposure / ND Filter utilities
:Forum: http://www.magiclantern.fm/forum/index.php?topic=12960.0

1) Set the ND filter strength in the menu.
2) Meter however you like without the ND filter attached (AutoETTR or Tv/Av or just manual).
3) Attach filter
4) Hold SET. Camera will switch to BULB mode and take a pic based on current expo settings and ND strength