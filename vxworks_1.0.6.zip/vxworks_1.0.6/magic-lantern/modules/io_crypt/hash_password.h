
#ifndef __HASH_PASSWORD_H
#define __HASH_PASSWORD_H

void hash_password(char *password, uint64_t *hash);

#endif