File Manager
============

:Authors: ML devs
:License: GPL
:Summary: File manager (browse the files on the card)
:Forum: http://www.magiclantern.fm/forum/index.php?topic=5522.0

Browse the card filesystem from ML menu.

Features:

* Display file name, size and date
* Select files (individual or by extension)
* Copy and move files
* Delete files
* View files (text viewer built-in, other file types via custom handlers)
