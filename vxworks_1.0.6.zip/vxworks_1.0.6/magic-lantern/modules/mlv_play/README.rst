MLV Player
==========

Plays Magic Lantern video files (both MLV and RAW).
You can select videos for playback in the file_man module,
or you can press the PLAY key in LV to play the most recent recording.

* "all": play every video frame
* "exact": drop video frames to match recorded FPS

Keys:

* SET: use the on-screen menu
* PLAY: pause or resume playback
* INFO: toggle display of video information
* wheel: switch to previous or next video

:License: GPL
:Summary: Play MLV/RAW
:Authors: g3gg0, a1ex, ayshih
:Forum: http://www.magiclantern.fm/forum/index.php?topic=9062.0
