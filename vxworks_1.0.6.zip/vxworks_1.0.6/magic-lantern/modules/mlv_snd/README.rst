MLV Sound Support
=================

With this module, mlv_rec is extended by sound recording support.

:Author: g3gg0
:License: GPL
:Summary: Adds sound recording functionality to mlv_rec
:Website: http://www.magiclantern.fm/
