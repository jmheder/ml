Scripting GUI
=============

Scripting GUI (work in progress)

:Author: a1ex
:License: GPL
:Summary: Scripting GUI (work in progress)


